local_ip = "127.0.0.1"

port_atm = 8000
port_router = 8001
port_bank = 8002

buf_size = 60000

