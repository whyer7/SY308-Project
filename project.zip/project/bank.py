import config
import socket
import select
import sys
import pickle
from atm import *
import os
from Crypto import Random
from Crypto.Cipher import AES
import hashlib


class bank:
  def __init__(self):
    self.s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    self.s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    self.s.bind((config.local_ip, config.port_bank))
    #====================================================================
    # TO DO: Add any class variables your ATM needs in the __init__
    # function below this.  For example, user balances, PIN numbers
    # etc.
    #====================================================================

    self.Alice = 100
    self.Bob = 100
    self.Carol = 0
    self.AlicePIN = "0815"
    self.BobPIN = "9356"
    self.CarolPIN = "4792"

  #====================================================================
  # TO DO: Modify the following function to handle the console input
  # Every time a user enters a command at the bank terminal, it comes
  # to this function as the variable "inString"
  # The current implementation simply sends this string to the ATM
  # as a demonstration.  You will want to remove this and instead process
  # this string to deposit money, check balance, etc.
  #====================================================================
  def handleLocal(self,inString):
    #self.send(inString)

    inString = inString.split()
    command = inString[0]
    person = inString[1]
    if command == "balance":
      if person == "Alice":
        print("$" + str(self.Alice))
      elif person == "Bob":
        print("$" + str(self.Bob))
      elif person == "Carol":
        print("$" + str(self.Carol))
      else:
        print("This person does not have an account!")
        return None
    if command == "deposit":
      if len(inString) != 3:
        print("Invalid format!")
        return None
      amount = inString[2]
      if person == "Alice":
        self.Alice += int(amount)
        print("$"+ str(amount) +" added to Alice's account")
      elif person == "Bob":
        self.Bob += int(amount)
        print("$"+ str(amount) +" added to Bob's account")
      elif person == "Carol":
        self.Carol += int(amount)
        print("$"+ str(amount) +" added to Carols's account")
      else:
        print("This person does not have an account!")
        return None
    

  
  #====================================================================
  # TO DO: Modify the following function to handle the atm request 
  # Every time a message is received from the ATM, it comes to this
  # function as "inObject".  You will want to process this message
  # and potentially allow a user to login, dispense money, etc.
  # You will then have to respond to the ATM by calling the send() 
  # function to notify the ATM of any action you approve or disapprove.
  # Right now it just prints any message sent from the ATM to the screen
  # and sends the same message back to the ATM.
  #====================================================================
  def handleRemote(self, inObject):
    print(" Command Received from ATM")
    ##self.send(inObject)
    k = open('ssBank.bin', "rb").read()       
    c = inObject
    iv = c[:16]
    c0=c[16:]
    decr = self.decrypt_basic(k, iv, c0)
    decr = decr.decode('utf-8')
    

    inString = decr.split()
    command = inString[0]
    person = inString[1]

    if command == "verification":
      if person == "Alice":
        if self.AlicePIN == inString[2]:
          iv = Random.new().read(AES.block_size)
          message = "validUser" + "Alice"
          key = os.urandom(16)
          open('ssATM.bin', "wb").write(key)
          m = bytes(message, 'utf-8')
          c0 = self.encrypt_basic(key, iv, m)
          fullCipher = (iv + c0)
          self.send(fullCipher)
        else:
          iv = Random.new().read(AES.block_size)
          message = "Unauthorized"
          key = os.urandom(16)
          open('ssATM.bin', "wb").write(key)
          m = bytes(message, 'utf-8')
          c0 = self.encrypt_basic(key, iv, m)
          fullCipher = (iv + c0)
          self.send(fullCipher)
      if person == "Bob":
        if self.BobPIN == inString[2]:
          iv = Random.new().read(AES.block_size)
          message = "validUser " + "Bob"
          key = os.urandom(16)
          open('ssATM.bin', "wb").write(key)
          m = bytes(message, 'utf-8')
          c0 = self.encrypt_basic(key, iv, m)
          fullCipher = (iv + c0)
          self.send(fullCipher)
        else:
          iv = Random.new().read(AES.block_size)
          message = "Unauthorized"
          key = os.urandom(16)
          open('ssATM.bin', "wb").write(key)
          m = bytes(message, 'utf-8')
          c0 = self.encrypt_basic(key, iv, m)
          fullCipher = (iv + c0)
          self.send(fullCipher)
          
      if person == "Carol":
        if self.CarolPIN == inString[2]:
          iv = Random.new().read(AES.block_size)
          message = "validUser " + "Carol"
          key = os.urandom(16)
          open('ssATM.bin', "wb").write(key)
          m = bytes(message, 'utf-8')
          c0 = self.encrypt_basic(key, iv, m)
          fullCipher = (iv + c0)
          self.send(fullCipher)
        else:
          self.send("Unauthorized")
   
    if command == "balance":
      if person == "Alice":
        iv = Random.new().read(AES.block_size)
        message = "Balance: $" + str(self.Alice)
        key = os.urandom(16)
        open('ssATM.bin', "wb").write(key)
        m = bytes(message, 'utf-8')
        c0 = self.encrypt_basic(key, iv, m)
        fullCipher = (iv + c0)
        self.send(fullCipher)
      elif person == "Bob":
        iv = Random.new().read(AES.block_size)
        message = "Balance: $" + str(self.Bob)
        key = os.urandom(16)
        open('ssATM.bin', "wb").write(key)
        m = bytes(message, 'utf-8')
        c0 = self.encrypt_basic(key, iv, m)
        fullCipher = (iv + c0)
        self.send(fullCipher)
      elif person == "Carol":
        iv = Random.new().read(AES.block_size)
        message = "Balance: $" + str(self.Carol)
        key = os.urandom(16)
        open('ssATM.bin', "wb").write(key)
        m = bytes(message, 'utf-8')
        c0 = self.encrypt_basic(key, iv, m)
        fullCipher = (iv + c0)
        self.send(fullCipher)
      else:
        #print("This person does not have an account!")
        return None

    if command == "withdraw":
      if len(inString) != 3:
        iv = Random.new().read(AES.block_size)
        message = "Invalid format!"
        key = os.urandom(16)
        open('ssATM.bin', "wb").write(key)
        m = bytes(message, 'utf-8')
        c0 = self.encrypt_basic(key, iv, m)
        fullCipher = (iv + c0)
        self.send(fullCipher)
        return None
      amount = inString[2]
      if person == "Alice":
        if self.Alice >= int(amount): 
          self.Alice -= int(amount)
          iv = Random.new().read(AES.block_size)
          message = "$"+ str(amount) +" dispensed"
          key = os.urandom(16)
          open('ssATM.bin', "wb").write(key)
          m = bytes(message, 'utf-8')
          c0 = self.encrypt_basic(key, iv, m)
          fullCipher = (iv + c0)
          self.send(fullCipher)
        else:
          self.Alice -= int(amount)
          iv = Random.new().read(AES.block_size)
          message = "Insufficient funds"
          key = os.urandom(16)
          open('ssATM.bin', "wb").write(key)
          m = bytes(message, 'utf-8')
          c0 = self.encrypt_basic(key, iv, m)
          fullCipher = (iv + c0)
          self.send(fullCipher)
      elif person == "Bob":
        if self.Bob >= int(amount):
          self.Bob -= int(amount)
          iv = Random.new().read(AES.block_size)
          message = "$"+ str(amount) +" dispensed"
          key = os.urandom(16)
          open('ssATM.bin', "wb").write(key)
          m = bytes(message, 'utf-8')
          c0 = self.encrypt_basic(key, iv, m)
          fullCipher = (iv + c0)
          self.send(fullCipher)
        else:
          self.Alice -= int(amount)
          iv = Random.new().read(AES.block_size)
          message = "Insufficient funds"
          key = os.urandom(16)
          open('ssATM.bin', "wb").write(key)
          m = bytes(message, 'utf-8')
          c0 = self.encrypt_basic(key, iv, m)
          fullCipher = (iv + c0)
          self.send(fullCipher)
      elif person == "Carol":
        if self.Carol >= int(amount):
          self.Carol -= int(amount)
          iv = Random.new().read(AES.block_size)
          message = "$"+ str(amount) +" dispensed"
          key = os.urandom(16)
          open('ssATM.bin', "wb").write(key)
          m = bytes(message, 'utf-8')
          c0 = self.encrypt_basic(key, iv, m)
          fullCipher = (iv + c0)
          self.send(fullCipher)
        else:
          self.Alice -= int(amount)
          iv = Random.new().read(AES.block_size)
          message = "Insufficient funds"
          key = os.urandom(16)
          open('ssATM.bin', "wb").write(key)
          m = bytes(message, 'utf-8')
          c0 = self.encrypt_basic(key, iv, m)
          fullCipher = (iv + c0)
          self.send(fullCipher)
      else:
        self.Alice -= int(amount)
        iv = Random.new().read(AES.block_size)
        message = "Invalid"
        key = os.urandom(16)
        open('ssATM.bin', "wb").write(key)
        m = bytes(message, 'utf-8')
        c0 = self.encrypt_basic(key, iv, m)
        fullCipher = (iv + c0)
        self.send(fullCipher)
        
        return None


  #====================================================================
      
  def add_padding(self, data):
      padding = len(data) % 16
      if padding == 0:
          data += bytes.fromhex('10101010101010101010101010101010')
      if padding == 1:
          data += bytes.fromhex('0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f')
      if padding == 2:
          data += bytes.fromhex('0e0e0e0e0e0e0e0e0e0e0e0e0e0e')
      if padding == 3:
          data += bytes.fromhex('0d0d0d0d0d0d0d0d0d0d0d0d0d')
      if padding == 4:
          data += bytes.fromhex('0c0c0c0c0c0c0c0c0c0c0c0c')
      if padding == 5:
          data += bytes.fromhex('0b0b0b0b0b0b0b0b0b0b0b')
      if padding == 6:
          data += bytes.fromhex('0a0a0a0a0a0a0a0a0a0a')
      if padding == 7:
          data += bytes.fromhex('090909090909090909')
      if padding == 8:
          data += bytes.fromhex('0808080808080808')
      if padding == 9:
          data += bytes.fromhex('07070707070707')
      if padding == 10:
          data += bytes.fromhex('060606060606')
      if padding == 11:
          data += bytes.fromhex('0505050505')
      if padding == 12:
          data += bytes.fromhex('04040404')
      if padding == 13:
          data += bytes.fromhex('030303')
      if padding == 14:
          data += bytes.fromhex('0202')
      if padding == 15:
          data += bytes.fromhex('01')
      return data

  def remove_padding(self, data):
    if len(data)%16 != 0:
        return data[:1], False
    if len(data)%16 == 0:
        lastBlock = data[-16:]
        if lastBlock[-1:].hex() == "01":
            data=data[:-1]
            return data, True
        if lastBlock[-2:].hex() == "0202":
            data=data[:-2]
            return data, True
        if lastBlock[-3:].hex() == "030303":
            data=data[:-3]
            return data, True
        if lastBlock[-4:].hex() == "04040404":
            data=data[:-4]
            return data, True
        if lastBlock[-5:].hex() == "0505050505":
            data=data[:-5]
            return data, True
        if lastBlock[-6:].hex() == "060606060606":
            data=data[:-6]
            return data, True
        if lastBlock[-7:].hex() == "07070707070707":
            data=data[:-7]
            return data, True
        if lastBlock[-8:].hex() == "0808080808080808":
            data=data[:-8]
            return data, True
        if lastBlock[-9:].hex() == "090909090909090909":
            data=data[:-9]
            return data, True
        if lastBlock[-10:].hex() == "0a0a0a0a0a0a0a0a0a0a":
            data=data[:-10]
            return data, True
        if lastBlock[-11:].hex() == "0b0b0b0b0b0b0b0b0b0b0b":
            data=data[:-11]
            return data, True
        if lastBlock[-12:].hex() == "0c0c0c0c0c0c0c0c0c0c0c0c":
            data=data[:-12]
            return data, True
        if lastBlock[-13:].hex() == "0d0d0d0d0d0d0d0d0d0d0d0d0d":
            data=data[:-13]
            return data, True
        if lastBlock[-14:].hex() == "0e0e0e0e0e0e0e0e0e0e0e0e0e0e":
            data=data[:-14]
            return data, True
        if lastBlock[-15:].hex() == "0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f":
            data=data[:-15]
            return data, True
        if lastBlock[-16:].hex() == "10101010101010101010101010101010":
            data=data[:-16]
            return data, True
        else:
            return data[:1], False

          
  def encrypt_basic(self, k, iv, m):
    padded = self.add_padding(m)
    c = AES.new(k, AES.MODE_CBC, iv)
    c1 = (c.encrypt(padded))
    return c1
  

  def decrypt_basic(self, k, iv, c):
    try:
        decr = AES.new(k, AES.MODE_CBC, iv)
        return self.remove_padding(decr.decrypt(c))[0]
    except TypeError:
        x = bytes()
        return x

  #====================================================================
  # DO NOT MODIFY ANYTHING BELOW THIS UNLESS YOU ARE REALLY SURE YOU
  # NEED TO FOR YOUR APPROACH TO WORK. This is all the network IO code
  # that makes it possible for the ATM and bank to communicate.
  #====================================================================
  def prompt(self):
    sys.stdout.write("BANK:")
    sys.stdout.flush()

  def __del__(self):
    self.s.close()

  def send(self, m):
    self.s.sendto(pickle.dumps(m), (config.local_ip, config.port_router))

  def recvBytes(self):
    data, addr = self.s.recvfrom(config.buf_size)
    if addr[0] == config.local_ip and addr[1] == config.port_router:
      return True, data
    else:
      return False, bytes(0)

  def mainLoop(self):
    self.prompt()
  
    while True:
      l_socks = [sys.stdin, self.s]
           
      # Get the list sockets which are readable
      r_socks, w_socks, e_socks = select.select(l_socks, [], [])
           
      for s in r_socks:
        # Incoming data from the router
        if s == self.s:
          ret, data = self.recvBytes()
          if ret == True:
            self.handleRemote(pickle.loads(data)) # call handleRemote
            self.prompt() 
                                 
        # User entered a message
        elif s == sys.stdin:
          m = sys.stdin.readline().rstrip("\n")
          if m == "quit": 
            return
          self.handleLocal(m) # call handleLocal
          self.prompt() 
        

if __name__ == "__main__":
  b = bank()
  b.mainLoop()

