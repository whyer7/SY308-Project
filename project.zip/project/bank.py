import config
import socket
import select
import sys
import pickle
from atm import *


class bank:
  def __init__(self):
    self.s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    self.s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    self.s.bind((config.local_ip, config.port_bank))
    #====================================================================
    # TO DO: Add any class variables your ATM needs in the __init__
    # function below this.  For example, user balances, PIN numbers
    # etc.
    #====================================================================

    self.Alice = 100
    self.Bob = 100
    self.Carol = 0
    self.AlicePIN = "1234"
    self.BobPIN = "0987"
    self.CarolPIN = "1111"

  #====================================================================
  # TO DO: Modify the following function to handle the console input
  # Every time a user enters a command at the bank terminal, it comes
  # to this function as the variable "inString"
  # The current implementation simply sends this string to the ATM
  # as a demonstration.  You will want to remove this and instead process
  # this string to deposit money, check balance, etc.
  #====================================================================
  def handleLocal(self,inString):
    #self.send(inString)

    inString = inString.split()
    command = inString[0]
    person = inString[1]
    if command == "balance":
      if person == "Alice":
        print("$" + str(self.Alice))
      elif person == "Bob":
        print("$" + str(self.Bob))
      elif person == "Carol":
        print("$" + str(self.Carol))
      else:
        print("This person does not have an account!")
        return None
    if command == "deposit":
      if len(inString) != 3:
        print("Invalid format!")
        return None
      amount = inString[2]
      if person == "Alice":
        self.Alice += int(amount)
        print("$"+ str(amount) +" added to Alice's account")
      elif person == "Bob":
        self.Bob += int(amount)
        print("$"+ str(amount) +" added to Bob's account")
      elif person == "Carol":
        self.Carol += int(amount)
        print("$"+ str(amount) +" added to Carols's account")
      else:
        print("This person does not have an account!")
        return None
    

  
  #====================================================================
  # TO DO: Modify the following function to handle the atm request 
  # Every time a message is received from the ATM, it comes to this
  # function as "inObject".  You will want to process this message
  # and potentially allow a user to login, dispense money, etc.
  # You will then have to respond to the ATM by calling the send() 
  # function to notify the ATM of any action you approve or disapprove.
  # Right now it just prints any message sent from the ATM to the screen
  # and sends the same message back to the ATM.
  #====================================================================
  def handleRemote(self, inObject):
    print(inObject)
    ##self.send(inObject)

    inString = inObject.split()
    command = inString[0]
    person = inString[1]

    if command == "verification":
      if person == "Alice":
        if self.AlicePIN == inString[2]:
          self.send("validUser " + "Alice")
        else:
          self.send("Unauthorized")
      if person == "Bob":
        if self.BobPIN == inString[2]:
          self.send("validUser " + "Bob")
        else:
          self.send("Unauthorized")
      if person == "Carol":
        if self.CarolPIN == inString[2]:
          self.send("validUser " + "Carol")
        else:
          self.send("Unauthorized")
   
    if command == "balance":
      if person == "Alice":
        self.send("Balance: $" + str(self.Alice))
      elif person == "Bob":
        self.send("Balance: $" + str(self.Bob))
      elif person == "Carol":
        self.send("Balance: $" + str(self.Carol))
      else:
        #print("This person does not have an account!")
        return None

    if command == "withdraw":
      if len(inString) != 3:
        self.send("Invalid format!")
        return None
      amount = inString[2]
      if person == "Alice":
        if self.Alice >= int(amount): 
          self.Alice -= int(amount)
          self.send("$"+ str(amount) +" dispensed")
        else:
          self.send("Insufficient funds")
      elif person == "Bob":
        if self.Bob >= int(amount):
          self.Bob -= int(amount)
          self.send("$"+ str(amount) +" dispensed")
        else:
          self.send("Insufficient funds")
      elif person == "Carol":
        if self.Carol >= int(amount):
          self.Carol -= int(amount)
          self.send("$"+ str(amount) +" dispensed")
        else:
          self.send("Insufficient funds")
      else:
        self.send("Invalid")
        return None


  #====================================================================
  # DO NOT MODIFY ANYTHING BELOW THIS UNLESS YOU ARE REALLY SURE YOU
  # NEED TO FOR YOUR APPROACH TO WORK. This is all the network IO code
  # that makes it possible for the ATM and bank to communicate.
  #====================================================================
  def prompt(self):
    sys.stdout.write("BANK:")
    sys.stdout.flush()

  def __del__(self):
    self.s.close()

  def send(self, m):
    self.s.sendto(pickle.dumps(m), (config.local_ip, config.port_router))

  def recvBytes(self):
    data, addr = self.s.recvfrom(config.buf_size)
    if addr[0] == config.local_ip and addr[1] == config.port_router:
      return True, data
    else:
      return False, bytes(0)

  def mainLoop(self):
    self.prompt()
  
    while True:
      l_socks = [sys.stdin, self.s]
           
      # Get the list sockets which are readable
      r_socks, w_socks, e_socks = select.select(l_socks, [], [])
           
      for s in r_socks:
        # Incoming data from the router
        if s == self.s:
          ret, data = self.recvBytes()
          if ret == True:
            self.handleRemote(pickle.loads(data)) # call handleRemote
            self.prompt() 
                                 
        # User entered a message
        elif s == sys.stdin:
          m = sys.stdin.readline().rstrip("\n")
          if m == "quit": 
            return
          self.handleLocal(m) # call handleLocal
          self.prompt() 
        

if __name__ == "__main__":
  b = bank()
  b.mainLoop()

