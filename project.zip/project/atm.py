import config
import socket
import select
import sys
import json
import pickle
from bank import *
import os
from Crypto import Random
from Crypto.Cipher import AES
import hashlib


class atm:
  def __init__(self):
    self.s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    self.s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    self.s.bind((config.local_ip, config.port_atm))
    #====================================================================
    # TO DO: Add any class variables your ATM needs in the __init__
    # function below this.  I have started with two variables you might
    # want, the loggedIn flag which indicates if someone is logged in to
    # the ATM or not and the user variable which holds the name of the
    # user currently logged in.
    #====================================================================
    self.loggedIn = False
    self.user = None

  #====================================================================
  # TO DO: Modify the following function to handle the console input
  # Every time a user enters a command at the ATM terminal, it comes
  # to this function as the variable "inString"
  # The current implementation simply sends this string to the bank
  # as a demonstration.  You will want to remove this and instead process
  # this string and determine what, if any, message you want to send to
  # the bank.
  #====================================================================
  def handleLocal(self,inString):
    ##self.send(inString)
    
    inString = inString.split()
    command = inString[0]
    if command == "begin-session":
      try:
        verify = open("Inserted.card", "r")
      except:
        print("no card")
        return
      
      contents = verify.read()
      if "Alice" and "BERKELEYDRIVENJ" in contents:
        user = "Alice"
        key = os.urandom(16)
        open('ssBank.bin', "wb").write(key)
      elif "Bob" and "JEROMEJAYDRIVEMD" in contents:
        user = "Bob"
        key = os.urandom(16)
        open('ssBank.bin', "wb").write(key)
      elif "Carol" and "FEBRUARYPOINTBHS" in contents:
        user = "Carol"
        key = os.urandom(16)
        open('ssBank.bin', "wb").write(key)
      PIN = input("Enter your PIN: ")
      iv = Random.new().read(AES.block_size)
      message = "verification " + user + " " + str(PIN)
      m = bytes(message, 'utf-8')
      c0 = self.encrypt_basic(key, iv, m)
      fullCipher = (iv + c0)
      self.send(fullCipher)

    if self.loggedIn == True:
      if command == "balance":
        iv = Random.new().read(AES.block_size)
        message = command + " " + self.user
        key = os.urandom(16)
        open('ssBank.bin', "wb").write(key)
        m = bytes(message, 'utf-8')
        c0 = self.encrypt_basic(key, iv, m)
        fullCipher = (iv + c0)
        self.send(fullCipher)
      elif command == "withdraw":
        if len(inString) == 2:
          iv = Random.new().read(AES.block_size)
          message = command + " " + self.user + " " + str(inString[1]) #assuming string is 2 or more
          key = os.urandom(16)
          open('ssBank.bin', "wb").write(key)
          m = bytes(message, 'utf-8')
          c0 = self.encrypt_basic(key, iv, m)
          fullCipher = (iv + c0)
          self.send(fullCipher)
        else:
          print("Not a valid command")
      elif command == "end-session":
        self.loggedIn = False
        self.user = None
        print("User logged out")
        return 
##    elif self.loggedIn != True:
##      print("No user logged in")


  #====================================================================
  # TO DO: Modify the following function to handle the bank's messages.
  # Every time a message is received from the bank, it comes to this
  # function as "inObject".  You will want to process this message
  # and potentially allow a user to login, dispense money, etc.
  # Right now it just prints any message sent from the bank to the screen.
  #====================================================================
  def handleRemote(self, inObject):
    
    k = open('ssATM.bin', "rb").read()       
    c = inObject
    iv = c[:16]
    c0=c[16:]
    decr = self.decrypt_basic(k, iv, c0)
    decr = decr.decode('utf-8')
  
    if "validUser" in decr:
      self.loggedIn = True
      if "Alice" in decr:
        self.user = "Alice"
      elif "Bob" in decr:
        self.user = "Bob"
      elif "Carol" in decr:
        self.user = "Carol"
      print("\nAuthorized")

    if "Unauthorized" in decr:
      print("\nUnauthorized")

    if self.loggedIn == True:
      if "Balance" in decr:
        print("\n" + decr)
      elif "dispensed" in decr:
        print("\n" + decr)
      elif "Insufficient" in decr:
        print("\nInsufficient funds")


  #====================================================================
        

  def add_padding(self, data):
    padding = len(data) % 16
    if padding == 0:
        data += bytes.fromhex('10101010101010101010101010101010')
    if padding == 1:
        data += bytes.fromhex('0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f')
    if padding == 2:
        data += bytes.fromhex('0e0e0e0e0e0e0e0e0e0e0e0e0e0e')
    if padding == 3:
        data += bytes.fromhex('0d0d0d0d0d0d0d0d0d0d0d0d0d')
    if padding == 4:
        data += bytes.fromhex('0c0c0c0c0c0c0c0c0c0c0c0c')
    if padding == 5:
        data += bytes.fromhex('0b0b0b0b0b0b0b0b0b0b0b')
    if padding == 6:
        data += bytes.fromhex('0a0a0a0a0a0a0a0a0a0a')
    if padding == 7:
        data += bytes.fromhex('090909090909090909')
    if padding == 8:
        data += bytes.fromhex('0808080808080808')
    if padding == 9:
        data += bytes.fromhex('07070707070707')
    if padding == 10:
        data += bytes.fromhex('060606060606')
    if padding == 11:
        data += bytes.fromhex('0505050505')
    if padding == 12:
        data += bytes.fromhex('04040404')
    if padding == 13:
        data += bytes.fromhex('030303')
    if padding == 14:
        data += bytes.fromhex('0202')
    if padding == 15:
        data += bytes.fromhex('01')
    return data

  def remove_padding(self, data):
    if len(data)%16 != 0:
        return data[:1], False
    if len(data)%16 == 0:
        lastBlock = data[-16:]
        if lastBlock[-1:].hex() == "01":
            data=data[:-1]
            return data, True
        if lastBlock[-2:].hex() == "0202":
            data=data[:-2]
            return data, True
        if lastBlock[-3:].hex() == "030303":
            data=data[:-3]
            return data, True
        if lastBlock[-4:].hex() == "04040404":
            data=data[:-4]
            return data, True
        if lastBlock[-5:].hex() == "0505050505":
            data=data[:-5]
            return data, True
        if lastBlock[-6:].hex() == "060606060606":
            data=data[:-6]
            return data, True
        if lastBlock[-7:].hex() == "07070707070707":
            data=data[:-7]
            return data, True
        if lastBlock[-8:].hex() == "0808080808080808":
            data=data[:-8]
            return data, True
        if lastBlock[-9:].hex() == "090909090909090909":
            data=data[:-9]
            return data, True
        if lastBlock[-10:].hex() == "0a0a0a0a0a0a0a0a0a0a":
            data=data[:-10]
            return data, True
        if lastBlock[-11:].hex() == "0b0b0b0b0b0b0b0b0b0b0b":
            data=data[:-11]
            return data, True
        if lastBlock[-12:].hex() == "0c0c0c0c0c0c0c0c0c0c0c0c":
            data=data[:-12]
            return data, True
        if lastBlock[-13:].hex() == "0d0d0d0d0d0d0d0d0d0d0d0d0d":
            data=data[:-13]
            return data, True
        if lastBlock[-14:].hex() == "0e0e0e0e0e0e0e0e0e0e0e0e0e0e":
            data=data[:-14]
            return data, True
        if lastBlock[-15:].hex() == "0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f":
            data=data[:-15]
            return data, True
        if lastBlock[-16:].hex() == "10101010101010101010101010101010":
            data=data[:-16]
            return data, True
        else:
            return data[:1], False


  def encrypt_basic(self, k, iv, m):
    padded = self.add_padding(m)
    c = AES.new(k, AES.MODE_CBC, iv)
    c1 = (c.encrypt(padded))
    return c1
  

  def decrypt_basic(self, k, iv, c):
    try:
        decr = AES.new(k, AES.MODE_CBC, iv)
        return self.remove_padding(decr.decrypt(c))[0]
    except TypeError:
        x = bytes()
        return x

  #====================================================================
  # DO NOT MODIFY ANYTHING BELOW THIS UNLESS YOU ARE REALLY SURE YOU
  # NEED TO FOR YOUR APPROACH TO WORK. This is all the network IO code
  # that makes it possible for the ATM and bank to communicate.
  #====================================================================
  def prompt(self):
    print("ATM" + (" (" + self.user + ")" if self.user != None else "") + ":", end="")
    sys.stdout.flush()

  def __del__(self):
    self.s.close()

  def send(self, m):
    self.s.sendto(pickle.dumps(m), (config.local_ip, config.port_router))

  def recvBytes(self):
      data, addr = self.s.recvfrom(config.buf_size)
      if addr[0] == config.local_ip and addr[1] == config.port_router:
        return True, data
      else:
        return False, bytes(0)

  def mainLoop(self):
    self.prompt()
  
    while True:
      l_socks = [sys.stdin, self.s]
           
      # Get the list sockets which are readable
      r_socks, w_socks, e_socks = select.select(l_socks, [], [])
           
      for s in r_socks:
        # Incoming data from the router
        if s == self.s:
          ret, data = self.recvBytes()
          if ret == True:
            self.handleRemote(pickle.loads(data)) # call handleRemote 
            self.prompt() 
            
                                 
        # User entered a message
        elif s == sys.stdin:
          m = sys.stdin.readline().rstrip("\n")
          if m == "quit": 
            return
          self.handleLocal(m) # call handleLocal
          self.prompt() 
    
         
if __name__ == "__main__":
  a = atm()
  a.mainLoop()
    
